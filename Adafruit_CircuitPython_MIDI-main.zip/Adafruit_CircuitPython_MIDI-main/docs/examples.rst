Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/midi_simpletest.py
    :caption: examples/midi_simpletest.py
    :linenos:
